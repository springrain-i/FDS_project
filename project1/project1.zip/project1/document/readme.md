This file will tell you the proper order of browing

* First: please read the README.md in the code file.
* Second: Follow the file instruction.
* If your are interested in the source code,please open the search.c in code file.

