This file will tell you the proper order of browing

* First: please read the README.md in the code file.
* Second: Follow the file instruction.
* Three: It is recommended that you also refer to the report, because it will help you better understand
* Four: the file named dataN  is the test data, you can use it to test my code.